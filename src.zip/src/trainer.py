"""Bucle de entrenamiento / evaluación común para Mask2Former y EffPS-Lite."""
import json
import math
import time
from pathlib import Path

import torch
from torch.nn.utils import clip_grad_norm_

from .config import CLASS_NAMES, NUM_CLASSES, OUTPUTS_DIR, WEIGHTS_DIR
from .metrics import SegMetrics, check_targets


@torch.no_grad()
def evaluate(model, loader, device, threshold=0.5):
    """Evalúa sobre un loader y devuelve {'overall': {...}, 'per_class': {...}}."""
    metrics = SegMetrics(threshold=threshold)
    for batch in loader:
        probs, _ = model.predict(batch["image"], panoptic=False)
        metrics.update(probs, batch["gt"])
    return metrics.compute()


def _mean_losses(acc, n):
    return {k: v / max(n, 1) for k, v in acc.items()}


def fit(model, loaders, device, epochs=30, lr=1e-4, patience=8, warmup_epochs=1,
        weight_decay=1e-4, tag=None, weights_path=None, log=print):
    """Entrena y guarda el mejor modelo (por mIoU en validación). Devuelve el historial."""
    tag = tag or model.name
    weights_path = Path(weights_path or WEIGHTS_DIR / f"{tag}_best.pt")
    weights_path.parent.mkdir(parents=True, exist_ok=True)
    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)

    opt = torch.optim.AdamW(model.param_groups(lr), weight_decay=weight_decay)
    steps_per_epoch = max(len(loaders["train"]), 1)
    total, warm = epochs * steps_per_epoch, warmup_epochs * steps_per_epoch
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: (s + 1) / warm if s < warm else 0.5 * (1 + math.cos(math.pi * (s - warm) / max(total - warm, 1))))
    use_amp = bool(model.use_amp and str(device).startswith("cuda"))
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)

    hist = {"epoch": [], "train_loss": [], "val_loss": [], "val_mIoU": [], "lr": []}
    best, bad = -1.0, 0
    for ep in range(1, epochs + 1):
        t0 = time.time()
        # ----------------------------- entrenamiento
        acc, n = {}, 0
        for batch in loaders["train"]:
            with torch.autocast("cuda", dtype=torch.float16, enabled=use_amp):
                losses = model.train_loss(batch)
            opt.zero_grad(set_to_none=True)
            scaler.scale(losses["loss"]).backward()
            scaler.unscale_(opt)
            clip_grad_norm_([p for g in opt.param_groups for p in g["params"]], 1.0)
            scaler.step(opt)
            scaler.update()
            sched.step()
            for k, v in losses.items():
                acc[k] = acc.get(k, 0.0) + float(v.detach())
            n += 1
        tr = _mean_losses(acc, n)
        # ----------------------------- validación (pérdida + mIoU)
        acc, n = {}, 0
        for batch in loaders["val"]:
            with torch.autocast("cuda", dtype=torch.float16, enabled=use_amp):
                losses = model.val_loss(batch)
            for k, v in losses.items():
                acc[k] = acc.get(k, 0.0) + float(v.detach())
            n += 1
        va = _mean_losses(acc, n)
        miou = evaluate(model, loaders["val"], device)["overall"]["IoU"]

        hist["epoch"].append(ep)
        hist["train_loss"].append(tr["loss"])
        hist["val_loss"].append(va["loss"])
        hist["val_mIoU"].append(miou)
        hist["lr"].append(opt.param_groups[-1]["lr"])
        flag = ""
        if miou > best:
            best, bad, flag = miou, 0, "  <- mejor"
            model.save(weights_path, extra={"epoch": ep, "val_mIoU": miou})
        else:
            bad += 1
        log(f"[{tag}] ép {ep:02d}/{epochs}  train {tr['loss']:.4f}  val {va['loss']:.4f}  "
            f"val mIoU {miou:.4f}  ({time.time() - t0:.0f}s){flag}")
        (OUTPUTS_DIR / f"history_{tag}.json").write_text(json.dumps(hist, indent=2), encoding="utf-8")
        if bad >= patience:
            log(f"[{tag}] sin mejora en {patience} épocas -> early stopping")
            break
    return hist


@torch.no_grad()
def tune_thresholds(model, loader, bins=200):
    """Elige, para cada clase, el umbral que maximiza el IoU en el conjunto de VALIDACIÓN.

    Se acumulan histogramas de probabilidad de píxeles positivos/negativos y se recorre
    cada umbral posible (sin volver a pasar las imágenes por el modelo).
    """
    pos = torch.zeros(NUM_CLASSES, bins, dtype=torch.float64)
    neg = torch.zeros(NUM_CLASSES, bins, dtype=torch.float64)
    for batch in loader:
        probs, _ = model.predict(batch["image"], panoptic=False)
        gt = batch["gt"].bool()
        idx = (probs * (bins - 1)).floor().long().clamp(0, bins - 1)
        for c in range(NUM_CLASSES):
            pos[c] += torch.bincount(idx[:, c][gt[:, c]], minlength=bins).double()
            neg[c] += torch.bincount(idx[:, c][~gt[:, c]], minlength=bins).double()
    thresholds = []
    for c in range(NUM_CLASSES):
        tp = pos[c].flip(0).cumsum(0).flip(0)    # píxeles de la clase con prob >= umbral k
        fp = neg[c].flip(0).cumsum(0).flip(0)    # píxeles de otras clases con prob >= umbral k
        fn = pos[c].sum() - tp
        thresholds.append((tp / (tp + fp + fn + 1e-9)).argmax().item() / (bins - 1))
    return thresholds


def evaluate_tuned(model, loaders, device):
    """Ajusta un umbral por clase en validación y evalúa en test con esos umbrales."""
    th = tune_thresholds(model, loaders["val"])
    res = evaluate(model, loaders["test"], device, threshold=th)
    res["thresholds"] = dict(zip(CLASS_NAMES, th))
    res["targets_ok"] = check_targets(res["overall"])
    return res


def test_best(model_cls, loaders, device, tag, weights_path=None, log=print):
    """Carga los mejores pesos, evalúa en test (umbral 0.5 y umbral por clase) y guarda
    outputs/metrics_<tag>.json."""
    weights_path = Path(weights_path or WEIGHTS_DIR / f"{tag}_best.pt")
    model = model_cls.load(weights_path, device)
    base = evaluate(model, loaders["test"], device)                       # umbral 0.5 en todas las clases
    res = evaluate_tuned(model, loaders, device)
    res["baseline_umbral_0.5"] = base["overall"]
    (OUTPUTS_DIR / f"metrics_{tag}.json").write_text(json.dumps(res, indent=2, ensure_ascii=False), encoding="utf-8")
    log(f"[{tag}] TEST (umbral 0.5)      " + "  ".join(f"{k}={v:.4f}" for k, v in base["overall"].items()))
    log(f"[{tag}] TEST (umbral x clase)  " + "  ".join(f"{k}={v:.4f}" for k, v in res["overall"].items()))
    return model, res

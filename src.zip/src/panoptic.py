"""Utilidades de visualización panóptica (usadas por el notebook y la app web).

Formato común de una predicción panóptica (ambos modelos):
    {"seg": np.int32 (H,W)  # id de segmento; 0 = vacío
     "segments": [{"id": int, "label_id": int, "score": float, "is_thing": bool}, ...]}
"""
import numpy as np

from .config import CLASS_COLORS, CLASS_NAMES, NUM_CLASSES, THING_IDS


def _segment_color(label_id, instance_rank, is_thing):
    base = np.array(CLASS_COLORS[label_id], dtype=np.float32)
    if is_thing:  # variar el tono por instancia para distinguir edificios vecinos
        shift = ((instance_rank * 37) % 90) - 45
        base = np.clip(base + shift * np.array([0.4, 1.0, 1.0]), 0, 255)
    return base


def colorize_panoptic(image, pan, alpha=0.55, draw_borders=True):
    """image: (H,W,3) uint8; pan: dict como el descrito arriba -> (H,W,3) uint8."""
    out = image.astype(np.float32).copy()
    seg = pan["seg"]
    rank = 0
    for s in pan["segments"]:
        m = seg == s["id"]
        if not m.any():
            continue
        col = _segment_color(s["label_id"], rank, s["is_thing"])
        out[m] = (1 - alpha) * out[m] + alpha * col
        rank += 1
    if draw_borders:
        b = np.zeros(seg.shape, bool)
        b[:, 1:] |= seg[:, 1:] != seg[:, :-1]
        b[1:, :] |= seg[1:, :] != seg[:-1, :]
        out[b] = (255, 255, 255)
    return out.clip(0, 255).astype(np.uint8)


def colorize_semantic(image, label_map, alpha=0.55):
    """label_map: (H,W) int con ids de clase, -1 = sin clase."""
    out = image.astype(np.float32).copy()
    for c in range(NUM_CLASSES):
        m = label_map == c
        out[m] = (1 - alpha) * out[m] + alpha * np.array(CLASS_COLORS[c], np.float32)
    return out.clip(0, 255).astype(np.uint8)


def gt_to_pan(gt, segments_fn):
    """Convierte las 4 máscaras del ground truth en el formato panóptico común."""
    masks, labels = segments_fn(gt)
    h, w = gt.shape[1:]
    seg = np.zeros((h, w), np.int32)
    segments = []
    for k, (m, lab) in enumerate(zip(masks, labels), start=1):
        seg[(m > 0) & (seg == 0)] = k
        segments.append({"id": k, "label_id": int(lab), "score": 1.0, "is_thing": int(lab) in THING_IDS})
    return {"seg": seg, "segments": segments}


def segments_summary(pan):
    """Cuenta de segmentos y área (%) por clase, para mostrar en la app."""
    seg, total = pan["seg"], pan["seg"].size
    rows = []
    for c in range(NUM_CLASSES):
        ss = [s for s in pan["segments"] if s["label_id"] == c]
        area = sum(int((seg == s["id"]).sum()) for s in ss)
        rows.append({"Clase": CLASS_NAMES[c], "Segmentos": len(ss), "Área (%)": round(100 * area / total, 2)})
    return rows


def legend_handles():
    import matplotlib.patches as mpatches
    return [mpatches.Patch(color=np.array(CLASS_COLORS[i]) / 255, label=CLASS_NAMES[i])
            for i in range(NUM_CLASSES)]


def class_overlay(image, pan, class_id, alpha=0.6):
    """Imagen con SOLO una zona resaltada (unión de los segmentos de esa clase)."""
    m = np.isin(pan["seg"], [s["id"] for s in pan["segments"] if s["label_id"] == class_id]) & (pan["seg"] > 0)
    out = image.astype(np.float32).copy()
    out[~m] *= 0.45                       # atenúa lo que no es la zona
    out[m] = (1 - alpha) * out[m] + alpha * np.array(CLASS_COLORS[class_id], np.float32)
    return out.clip(0, 255).astype(np.uint8), float(m.mean() * 100)


def draw_building_boxes(image, pan, building_id=1):
    """Dibuja la caja de cada edificio detectado (instancia) con su confianza."""
    from PIL import Image, ImageDraw
    im = Image.fromarray(image.copy())
    d = ImageDraw.Draw(im)
    n = 0
    for s in pan["segments"]:
        if s["label_id"] != building_id or not s["is_thing"]:
            continue
        ys, xs = np.where(pan["seg"] == s["id"])
        if len(xs) == 0:
            continue
        d.rectangle([xs.min(), ys.min(), xs.max(), ys.max()], outline=(255, 255, 0), width=1)
        n += 1
    return np.asarray(im), n

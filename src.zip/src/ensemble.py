"""Mejoras de inferencia SIN reentrenar: TTA (test-time augmentation) y ensamble de modelos.

Ambas clases exponen la misma interfaz `predict(images, panoptic, score_thr)` que los modelos,
así que se pueden pasar directamente a `evaluate` / `tune_thresholds`.
"""
import torch
import torch.nn.functional as F


class TTA:
    """Promedia las probabilidades de 8 versiones de la imagen (4 rotaciones x espejo)."""

    def __init__(self, model):
        self.model = model
        self.name = f"{model.name}+tta"

    @torch.no_grad()
    def predict(self, images, panoptic=True, score_thr=0.5):
        acc = 0
        for flip in (False, True):
            for k in range(4):
                x = images.flip(-1) if flip else images
                x = torch.rot90(x, k, (-2, -1))
                p, _ = self.model.predict(x, panoptic=False)
                p = torch.rot90(p, -k, (-2, -1))          # deshacer la rotación
                acc = acc + (p.flip(-1) if flip else p)    # deshacer el espejo
        pans = self.model.predict(images, True, score_thr)[1] if panoptic else None
        return acc / 8, pans


class Ensemble:
    """Promedia las probabilidades de varios modelos (p. ej. Mask2Former + EffPS-Lite)."""

    def __init__(self, models):
        self.models = models
        self.name = "ensamble"

    @torch.no_grad()
    def predict(self, images, panoptic=True, score_thr=0.5):
        probs = sum(m.predict(images, panoptic=False)[0] for m in self.models) / len(self.models)
        pans = self.models[0].predict(images, True, score_thr)[1] if panoptic else None
        return probs, pans


class Reescala:
    """Hace que un modelo entrenado a otro tamaño (p. ej. Mask2Former a 256 px) trabaje con imágenes más grandes (512 px)."""

    def __init__(self, model, size):
        self.model, self.size = model, size
        self.name = model.name

    @torch.no_grad()
    def predict(self, images, panoptic=True, score_thr=0.5):
        h = images.shape[-1]
        x = F.interpolate(images, size=(self.size, self.size), mode="bilinear", align_corners=False)
        p, _ = self.model.predict(x, panoptic=False)
        return F.interpolate(p, size=(h, h), mode="bilinear", align_corners=False), None

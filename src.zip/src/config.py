"""Configuración común del proyecto (clases, colores, rutas e hiperparámetros base)."""
from pathlib import Path

# ----------------------------------------------------------------------------
# Rutas
# ----------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data" / "reto-1-cartografa-automatizada"   # aquí se descomprime el dataset de Kaggle
OUTPUTS_DIR = ROOT / "outputs"                                 # curvas, métricas (json) y ejemplos
WEIGHTS_DIR = ROOT / "models" / "weights"                      # pesos del mejor modelo (.pt)

KAGGLE_DATASET = "cetaamb/reto-1-cartografa-automatizada"

# ----------------------------------------------------------------------------
# Clases (el orden coincide con los 4 canales de ground_truth_*.npy)
# ----------------------------------------------------------------------------
CLASS_NAMES = ["Área Caminable", "Área Construida", "Zona Verde", "Carretera"]
NUM_CLASSES = len(CLASS_NAMES)

# Panóptica: "Área Construida" se trata como *thing* (cada edificio es una
# instancia, obtenida con componentes conexas del ground truth). Las otras tres
# clases son *stuff* (un solo segmento por clase).
THING_IDS = [1]
STUFF_IDS = [0, 2, 3]
BUILDING_ID = 1

# Colores RGB (coherentes con los cmaps del notebook del profesor:
# Purples, Reds, Greens, Greys)
CLASS_COLORS = {
    0: (148, 103, 189),   # Área Caminable  - morado
    1: (214, 39, 40),     # Área Construida - rojo
    2: (44, 160, 44),     # Zona Verde      - verde
    3: (127, 127, 127),   # Carretera       - gris
}

# ----------------------------------------------------------------------------
# Hiperparámetros por defecto
# ----------------------------------------------------------------------------
IMG_SIZE = 256            # múltiplo de 32 (requisito del backbone EfficientNet/FPN)
MIN_SEGMENT_AREA = 20     # px (a IMG_SIZE) mínimos para considerar un segmento
SEED = 42
SPLIT = (0.70, 0.15, 0.15)  # train / val / test

# Umbrales mínimos pedidos por el profesor
TARGETS = {"IoU": 0.7, "mAP": 0.5, "F1": 0.8}

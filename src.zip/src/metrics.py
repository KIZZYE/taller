"""Métricas de segmentación por clase: IoU, precisión, recall, F1 y mAP (AP a nivel de píxel).

Ambos modelos entregan mapas de probabilidad (B,4,H,W). Con un umbral (0.5) se
obtiene la máscara binaria de cada clase y se acumulan TP/FP/FN sobre todo el
conjunto (no por imagen). El AP de cada clase se calcula con la curva
precisión-recall de las probabilidades; mAP = promedio del AP de las 4 clases.
"""
import torch
from torchmetrics.classification import BinaryAveragePrecision

from .config import CLASS_NAMES, NUM_CLASSES, TARGETS


class SegMetrics:
    def __init__(self, threshold=0.5, ap_bins=200, device="cpu"):
        # un solo umbral para todas las clases, o una lista con un umbral por clase
        self.thr = (torch.tensor(threshold, dtype=torch.float32).view(1, -1, 1, 1)
                    if isinstance(threshold, (list, tuple)) else threshold)
        self.tp = torch.zeros(NUM_CLASSES, dtype=torch.float64)
        self.fp = torch.zeros(NUM_CLASSES, dtype=torch.float64)
        self.fn = torch.zeros(NUM_CLASSES, dtype=torch.float64)
        # AP por clase con histograma de umbrales (memoria constante)
        self.ap = [BinaryAveragePrecision(thresholds=ap_bins).to(device) for _ in range(NUM_CLASSES)]

    @torch.no_grad()
    def update(self, probs, gt):
        """probs: (B,4,H,W) float en [0,1]; gt: (B,4,H,W) {0,1}."""
        gt = gt.to(probs.device).bool()
        pred = probs >= self.thr
        for c in range(NUM_CLASSES):
            p, g = pred[:, c], gt[:, c]
            self.tp[c] += (p & g).sum().item()
            self.fp[c] += (p & ~g).sum().item()
            self.fn[c] += (~p & g).sum().item()
            self.ap[c].update(probs[:, c].flatten(), g.flatten().int())

    def compute(self):
        eps = 1e-9
        tp, fp, fn = self.tp, self.fp, self.fn
        iou = tp / (tp + fp + fn + eps)
        prec = tp / (tp + fp + eps)
        rec = tp / (tp + fn + eps)
        f1 = 2 * tp / (2 * tp + fp + fn + eps)
        ap = torch.stack([m.compute().cpu() for m in self.ap]).double()
        per_class = {
            name: {"IoU": iou[i].item(), "Precisión": prec[i].item(), "Recall": rec[i].item(),
                   "F1": f1[i].item(), "AP": ap[i].item()}
            for i, name in enumerate(CLASS_NAMES)
        }
        overall = {"IoU": iou.mean().item(), "Precisión": prec.mean().item(),
                   "Recall": rec.mean().item(), "F1": f1.mean().item(), "mAP": ap.mean().item()}
        return {"overall": overall, "per_class": per_class}


def check_targets(overall):
    """Compara contra los mínimos del taller (IoU>=0.7, mAP>=0.5, F1>=0.8)."""
    return {k: (overall[k] >= v) for k, v in TARGETS.items()}


def image_metrics(probs, gt, threshold=0.5):
    """Métricas de UNA imagen. probs, gt: (4,H,W). Las clases ausentes en el gt se omiten (None)."""
    from torchmetrics.functional.classification import binary_average_precision
    gt = gt.bool()
    if isinstance(threshold, (list, tuple, dict)):   # un umbral por clase
        vals_t = list(threshold.values()) if isinstance(threshold, dict) else list(threshold)
        threshold = torch.tensor(vals_t, dtype=probs.dtype).view(-1, 1, 1)
    pred = probs >= threshold
    per_class, vals = {}, []
    for c, name in enumerate(CLASS_NAMES):
        g, p = gt[c], pred[c]
        if not g.any():
            per_class[name] = None
            continue
        tp = (p & g).sum().item(); fp = (p & ~g).sum().item(); fn = (~p & g).sum().item()
        d = {"IoU": tp / max(tp + fp + fn, 1), "Precisión": tp / max(tp + fp, 1),
             "Recall": tp / max(tp + fn, 1), "F1": 2 * tp / max(2 * tp + fp + fn, 1),
             "AP": binary_average_precision(probs[c].flatten(), g.flatten().int(), thresholds=200).item()}
        per_class[name] = d
        vals.append(d)
    overall = {k: sum(v[k] for v in vals) / len(vals) for k in ("IoU", "Precisión", "Recall", "F1", "AP")} if vals else None
    if overall:
        overall["mAP"] = overall.pop("AP")
    return {"overall": overall, "per_class": per_class}

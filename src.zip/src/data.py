"""Carga del dataset, división train/val/test, aumentos y construcción de segmentos panópticos."""
import json
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from scipy import ndimage
from torch.utils.data import DataLoader, Dataset

from .config import (BUILDING_ID, IMG_SIZE, MIN_SEGMENT_AREA, NUM_CLASSES, SEED,
                     SPLIT, THING_IDS)


# ----------------------------------------------------------------------------
# Descubrimiento de pares imagen / máscara
# ----------------------------------------------------------------------------
def find_pairs(data_dir):
    """Devuelve [(ruta_png, ruta_npy), ...] ordenado por nombre.

    El dataset usa el patrón  recorte_N.png  <->  ground_truth_recorte_N.npy
    (ver notebook de visualización del profesor).
    """
    data_dir = Path(data_dir)
    pairs = []
    for png in sorted(data_dir.rglob("*.png")):
        npy = png.with_name(f"ground_truth_{png.stem}.npy")
        if npy.exists():
            pairs.append((png, npy))
    if not pairs:
        raise FileNotFoundError(
            f"No se encontraron pares recorte_*.png / ground_truth_recorte_*.npy en {data_dir}. "
            "Revisa que el dataset de Kaggle esté descomprimido ahí.")
    return pairs


def make_splits(pairs, out_json=None, seed=SEED, ratios=SPLIT):
    """Divide en train/val/test de forma reproducible y guarda la división (json)."""
    idx = list(range(len(pairs)))
    random.Random(seed).shuffle(idx)
    n = len(idx)
    n_tr, n_va = int(ratios[0] * n), int(ratios[1] * n)
    splits = {
        "train": sorted(idx[:n_tr]),
        "val": sorted(idx[n_tr:n_tr + n_va]),
        "test": sorted(idx[n_tr + n_va:]),
    }
    if out_json:
        Path(out_json).parent.mkdir(parents=True, exist_ok=True)
        names = {k: [pairs[i][0].name for i in v] for k, v in splits.items()}
        Path(out_json).write_text(json.dumps(names, indent=2, ensure_ascii=False), encoding="utf-8")
    return splits


# ----------------------------------------------------------------------------
# Segmentos panópticos a partir de las 4 máscaras binarias
# ----------------------------------------------------------------------------
def build_segments(gt, min_area=MIN_SEGMENT_AREA):
    """gt: (4,H,W) uint8 -> (masks (n,H,W) uint8, labels (n,) int64).

    * stuff (caminable, verde, carretera): un segmento por clase.
    * thing (construida): una instancia por componente conexa (cada edificio).
    Las máscaras pueden solaparse (el dataset es multi-etiqueta); Mask2Former
    lo soporta porque cada query predice una máscara binaria independiente.
    """
    masks, labels = [], []
    for c in range(NUM_CLASSES):
        m = gt[c] > 0
        if m.sum() < min_area:
            continue
        if c in THING_IDS:
            lab, n = ndimage.label(m)
            for k in range(1, n + 1):
                comp = lab == k
                if comp.sum() >= min_area:
                    masks.append(comp)
                    labels.append(c)
        else:
            masks.append(m)
            labels.append(c)
    h, w = gt.shape[1:]
    if not masks:
        return np.zeros((0, h, w), np.uint8), np.zeros((0,), np.int64)
    return np.stack(masks).astype(np.uint8), np.asarray(labels, np.int64)


# ----------------------------------------------------------------------------
# Aumentos fuertes (para pocas imágenes de entrenamiento)
# ----------------------------------------------------------------------------
def augment_strong(img, gt, size):
    """img (3,H,W) float [0,1], gt (4,H,W) uint8 -> mismos tensores a `size`x`size`.

    * recorte aleatorio con zoom (55%-100% del lado) reescalado a `size`
    * espejo horizontal/vertical y rotación de 90°
    * brillo, contraste, saturación y gamma aleatorios
    """
    h = img.shape[-1]
    c = int(h * random.uniform(0.55, 1.0))
    y, x = random.randint(0, h - c), random.randint(0, h - c)
    img, gt = img[:, y:y + c, x:x + c], gt[:, y:y + c, x:x + c]
    img = F.interpolate(img[None], size=(size, size), mode="bilinear", align_corners=False)[0]
    gt = F.interpolate(gt[None].float(), size=(size, size), mode="nearest")[0].to(torch.uint8)
    if random.random() < 0.5:
        img, gt = img.flip(-1), gt.flip(-1)
    if random.random() < 0.5:
        img, gt = img.flip(-2), gt.flip(-2)
    k = random.randint(0, 3)
    if k:
        img, gt = torch.rot90(img, k, (1, 2)), torch.rot90(gt, k, (1, 2))
    gray = img.mean(0, keepdim=True)
    img = gray + (img - gray) * random.uniform(0.7, 1.3)                  # saturación
    img = (img - 0.5) * random.uniform(0.8, 1.25) + 0.5 + random.uniform(-0.08, 0.08)   # contraste y brillo
    img = img.clamp(0, 1) ** random.uniform(0.8, 1.25)                    # gamma
    return img.contiguous(), gt.contiguous()


# ----------------------------------------------------------------------------
# Dataset
# ----------------------------------------------------------------------------
class CartografiaDataset(Dataset):
    """Imagen RGB (3,H,W) float [0,1], gt (4,H,W) uint8 y segmentos panópticos."""

    def __init__(self, pairs, indices, img_size=IMG_SIZE, augment=False, skip_empty=True):
        self.pairs = [pairs[i] for i in indices]
        self.img_size = img_size
        self.augment = augment
        # Se leen y redimensionan UNA sola vez y se guardan en RAM (uint8): leer PNG/NPY en
        # cada época dejaba la GPU esperando a las 2 CPUs de Colab.
        kept, self._imgs, self._gts = [], [], []
        for p in self.pairs:
            img, gt = self._read(p)
            if skip_empty and not gt.any():   # sin ninguna máscara: no aporta al entrenamiento
                continue
            kept.append(p)
            self._imgs.append(img)
            self._gts.append(gt)
        self.pairs = kept

    def __len__(self):
        return len(self.pairs)

    def load_raw(self, i):
        """Imagen (H,W,3) y gt (4,H,W) redimensionados a img_size (sin aumentos)."""
        return self._imgs[i], self._gts[i]

    def _read(self, pair):
        png, npy = pair
        img = Image.open(png).convert("RGB").resize((self.img_size,) * 2, Image.BILINEAR)
        gt = np.load(npy)
        if gt.ndim == 2:  # por si alguna máscara viniera sin canal
            gt = gt[..., None]
        chans = []
        for c in range(NUM_CLASSES):  # redimensiona cada canal con vecino más cercano
            ch = Image.fromarray(((gt[..., c] > 0) * 255).astype(np.uint8))
            chans.append(np.asarray(ch.resize((self.img_size,) * 2, Image.NEAREST)) > 0)
        return np.array(img), np.stack(chans).astype(np.uint8)   # np.array: copia escribible

    def __getitem__(self, i):
        img, gt = self.load_raw(i)
        img = torch.from_numpy(img).permute(2, 0, 1).float() / 255.0
        gt = torch.from_numpy(gt)
        if self.augment == "strong":
            img, gt = augment_strong(img, gt, self.img_size)
        elif self.augment:  # imágenes satelitales: invariantes a flips y rotaciones de 90°
            if random.random() < 0.5:
                img, gt = img.flip(-1), gt.flip(-1)
            if random.random() < 0.5:
                img, gt = img.flip(-2), gt.flip(-2)
            k = random.randint(0, 3)
            if k:
                img, gt = torch.rot90(img, k, (1, 2)), torch.rot90(gt, k, (1, 2))
            # jitter leve de brillo/contraste
            img = (img * random.uniform(0.85, 1.15) + random.uniform(-0.05, 0.05)).clamp(0, 1)
        masks, labels = build_segments(gt.numpy())
        return {
            "image": img.contiguous(),
            "gt": gt.contiguous(),
            "seg_masks": torch.from_numpy(masks),
            "seg_labels": torch.from_numpy(labels),
        }


def collate(batch):
    """Los segmentos tienen número variable por imagen -> se dejan como listas."""
    return {
        "image": torch.stack([b["image"] for b in batch]),
        "gt": torch.stack([b["gt"] for b in batch]),
        "seg_masks": [b["seg_masks"] for b in batch],
        "seg_labels": [b["seg_labels"] for b in batch],
    }


def make_loaders(data_dir, batch_size=8, img_size=IMG_SIZE, num_workers=2, splits_json=None, augment=True):
    pairs = find_pairs(data_dir)
    splits = make_splits(pairs, out_json=splits_json)
    ds = {
        "train": CartografiaDataset(pairs, splits["train"], img_size, augment=augment),   # augment="strong" para aumentos fuertes
        "val": CartografiaDataset(pairs, splits["val"], img_size),
        "test": CartografiaDataset(pairs, splits["test"], img_size, skip_empty=False),
    }
    loaders = {
        k: DataLoader(v, batch_size=batch_size, shuffle=(k == "train"), drop_last=(k == "train"),
                      num_workers=num_workers, collate_fn=collate, pin_memory=torch.cuda.is_available(),
                      persistent_workers=num_workers > 0)
        for k, v in ds.items()
    }
    return ds, loaders

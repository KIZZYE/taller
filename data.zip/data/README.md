Aquí se descomprime el dataset de Kaggle `cetaamb/reto-1-cartografa-automatizada`
(carpeta `reto-1-cartografa-automatizada/`). El notebook lo descarga automáticamente.
